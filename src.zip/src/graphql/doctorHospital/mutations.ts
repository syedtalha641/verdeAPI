export const mutations = `#graphql
    createDoctorHospital(data:DoctorHospitalInput!):DoctorHospital
    removeDoctorHospital(data:DoctorHospitalInput!):DoctorHospital
`;
