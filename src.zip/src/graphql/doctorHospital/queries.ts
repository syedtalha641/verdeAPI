export const queries = `#graphql
      
`;
