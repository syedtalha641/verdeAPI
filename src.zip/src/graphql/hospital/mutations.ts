export const mutations = `#graphql
    createHospital(data:HospitalInput!):Hospital
`;
