export const mutations = `#graphql
    createPayment(data:PaymentInput!):Payment
`;
