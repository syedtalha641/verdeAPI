export const queries = `#graphql
      payments:[Payment],
      findPaymentById(id:ID!):Payment
`;
