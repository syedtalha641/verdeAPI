export const mutations = `#graphql
    createDoctorSpecialization(data:DoctorSpecializationInput!):DoctorSpecialization
`;
