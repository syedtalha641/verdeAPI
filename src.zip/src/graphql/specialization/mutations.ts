export const mutations = `#graphql
    createSpecialization(data:SpecializationInput!):Specialization
`;
