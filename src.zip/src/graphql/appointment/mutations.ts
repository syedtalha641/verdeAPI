export const mutations = `#graphql
    createAppointment(data:AppointmentInput!):Appointment
`;
