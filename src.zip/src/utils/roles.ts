export const USER_ROLES = {
  patient: "3582",
  doctor: "7964",
  admin: "4862",
};
